Current revision follows the user-edited Calc in assets/branding/zenq-icons-editable/zenq-icons.svg. The user's original file is preserved. Calc geometry, symbol, gradients and Gaussian blur are retained; other apps reuse the same frame and blur layers with application-specific colours and a 0.27 vertical shear on the interior symbol. IDs are namespaced to keep the combined sheet independent.

ZenQ editable SVG icons

Files: writer.svg, calc.svg, slides.svg, pdf.svg, creative.svg.
zenq-icons.svg: all five icons in one editable row.

Each icon contains named groups: back-ribbon, front-panel, gradient-fold, symbol.
Change colours by editing gradient stops in defs. PDF is editable SVG text.
All shapes are real vectors; there are no embedded PNG images or background removal masks.

The app reads these individual SVG files from assets/branding/editable first. Save edits and restart ZenQ Office to refresh the cached icons. Embedded copies provide a fallback.
